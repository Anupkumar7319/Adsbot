"""User activity tracking utilities.

Tracks last_active timestamp for each user and lets admins query active users
within a recent time window (e.g., last 30 minutes, last 24h, etc.).
"""
from datetime import timedelta
from db import users_col, now_utc


def update_user_activity(user_id: int, username: str = None):
    """Update last_active whenever the user interacts with the bot or web app."""
    upd = {'$set': {'last_active': now_utc()}}
    if username is not None:
        upd['$set']['username'] = username
    users_col.update_one({'_id': user_id}, upd, upsert=True)


def get_active_users(since_minutes: int = 30):
    cutoff = now_utc() - timedelta(minutes=since_minutes)
    return list(users_col.find({'last_active': {'$gte': cutoff}}))


def count_active_users(since_minutes: int = 30) -> int:
    cutoff = now_utc() - timedelta(minutes=since_minutes)
    return users_col.count_documents({'last_active': {'$gte': cutoff}})
